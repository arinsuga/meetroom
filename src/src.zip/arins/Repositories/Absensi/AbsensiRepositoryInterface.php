<?php

namespace Arins\Repositories\Absensi;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface AbsensiRepositoryInterface extends BaseRepositoryInterface
{
}