<?php

namespace Arins\Repositories\Activitystatus;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface ActivitystatusRepositoryInterface extends BaseRepositoryInterface
{
}