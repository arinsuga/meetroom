<?php

namespace Arins\Repositories\Activitytype;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface ActivitytypeRepositoryInterface extends BaseRepositoryInterface
{
}