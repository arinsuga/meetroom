<?php

namespace Arins\Repositories\Job;

use Arins\Repositories\BaseRepository;
use Arins\Repositories\Job\JobRepositoryInterface;

class JobRepository extends BaseRepository implements JobRepositoryInterface
{

}