<?php

namespace Arins\Repositories\Producttype;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface ProducttypeRepositoryInterface extends BaseRepositoryInterface
{
}