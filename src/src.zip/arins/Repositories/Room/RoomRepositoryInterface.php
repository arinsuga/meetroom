<?php

namespace Arins\Repositories\Room;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface RoomRepositoryInterface extends BaseRepositoryInterface
{
}