<?php

return [
    'hero1' => 'PT. Malindo Agrotek Perkasa focus to provide agriculture solution in Indonesia through technology as drone, seeds, fertilizer and agrochemical distributor.',
    'hero2' => 'PT. Malindo Agrotek Perkasa commited to produce high quality and reliable technology based agriculture product for harvesting tools.',
    'hero3' => 'PT. Malindo Agrotek Perkasa guarentee safety, comfort and customer satisfaction.',

    'mission' => 'Mission',
    'mission_text1' => 'Introduce new agriculture technology in Indonesia',
    'mission_text2' => 'Build a digital platform in agriculture business',
    'mission_text3' => 'Build capacities and skills through professional trainning and assignments',
    'mission_text4' => 'Partnering with principles, retailers and farmers to increase agriculture productivity in sustainable way',

    'vision' => 'Vision',
    'vision_text1' => 'To be number one agriculture distributor in Indonesia through innovation in technology, digital platform and excellence in services',
];
