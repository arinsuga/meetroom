<?php

return [
    'title' => 'OUR SERVICES',
    'desc1' => 'Malindo\'s drone technology in the agricultural sector has been running for the last few years. It has been developed by PT. Malindo Agrotek Perkasa to achieve our vision and mission',
    'desc2' => 'With drone technology, spraying can be done quickly, using less water, minimizing exposure of pesticides to the farmer, able to spray on difficult landscape',
    'desc3' => 'Drone increase efficiency and productivity for agriculture in Indonesia',
    'flyer' => 'DRONE FLYER',
    'apps' => 'CONTACT US VIA APPS',
];
