<?php

return [
    'title' => 'NATIONAL DISTRIBUTOR',
    'desc1' => 'In carrying distribution activities, PT. Malindo Agrotek Perkasa have 8 representative offices across Indonesia and continue to grow. Supported by nationwide distribution network, professional and qualified team, committed, high integrity to execute company strategy with responsibility in sustainable way',
    'desc2' => 'PT. Malindo Agrotek Perkasa offers technology solution from preparation, protection and processing of agriculture business',
    'desc3' => 'PT. Malindo Agrotek Perkasa is technology provider in agriculture that you can count on',
    'partners' => 'OUR PARTNERS',
];
