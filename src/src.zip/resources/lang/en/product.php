<?php

return [
    'product' => 'product',
    'type1' => 'AGRICULTURE TOOLS',
    'type2' => 'CROP PROTECTION',
    'type3' => 'FERTILIZER',
    'type4' => 'AGRICULTURE DRONE',
];
