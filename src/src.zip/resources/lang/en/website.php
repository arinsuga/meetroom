<?php

return [
    'pintu' => 'Open The Door',
];
